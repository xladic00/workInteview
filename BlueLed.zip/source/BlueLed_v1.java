import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 
import processing.serial.*; 
import ddf.minim.*; 
import processing.serial.*; 
import processing.serial.*; 
import processing.serial.*; 
import processing.serial.*; 
import processing.serial.*; 
import processing.serial.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class BlueLed_v1 extends PApplet {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// //<>// //<>//
///////////////////////////////////////////////IMPORT LIBRARIES////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////USER INTERFACE//////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ControlP5 rgbwheel;
PFont titlefont, buttonfont; 

Button barva, ruzova, fialova, zluta, oranzova, cervena, zelena, modra, cyan, hneda, maroon, golden, bila;
Button_mode   CylonBounce, RunningLights, theaterChase, Fillin_lane, meteorRain, Mode3, Music1, Music2, Music3, Rainbow, Minus, Plus ;//Fade
lumos_button lumos_button;
nox_button nox_button;


int colorbuttonx = 1600, colorbuttony = 350, colorbuttonw = 250, colorbuttonh = 60; //pro rychlejsi premystovani buttonbarvy
int r, g, b;
int r1;
String r2;
button_modes Fade;//Rainbow, Fade;

boolean keypressed = false;
Boolean button_menu = false;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////BLUETOOTH THINGS////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Bluetoothbutton BT;
int BT_count = 3;
int index_c = 0;

float count_connected = 0;
boolean BT_connected = false;
String[] COMS;
String[] COM_strings = new String[BT_count];
String [] BTdevices = new String[BT_count];
Boolean [] Devices_connected = new Boolean[BT_count];
boolean connected = false;
float [] BT_availables = new float[BT_count];
Serial Sending;
boolean TableConnected = false, BedConnected = false, AllConnected= false, clicked = false;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////// Draw led function /////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int red, green, blue;
int ledred = 255, ledgreen = 0, ledblue = 0;
boolean rr = true;
boolean gg = false;
boolean bb = false;
linerg line1, line2, line3, line4, line5, line6, line7, line8;
arcrg arc1;
public void keyPressed() {
  keypressed = true;
  if (key == ESC) {
    int [] exit_int = {5};
    int local_shit = sending_function(exit_int);
    exit();
  }
}
/*
private void prepareExitHandler () {
 Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
 
 public void run () {
 
 System.out.println("SHUTDOWN HOOK");
 int local_shit = sending_function(exit_int);
 }
 }
 ));
 }
 */

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////     SETUP      ////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
public void setup() {                  
  //fullScreen();
  
  //prepareExitHandler ();
  // fonty labelu, pak protridit
  titlefont= createFont("Georgia", 45);
  buttonfont=loadFont("AgencyFB-Bold-40.vlw");

  //definovani vsech tlacitek
  Deff_buttons();

  //definovani draw led funkce
  set_draw_led(100, 900, 0.5f);


  rgbwheel= new ControlP5(this);
  rgbwheel.addColorWheel("r1", 1300, 550, 400 ).setRGB(color(128, 0, 255));

  ////////////////////////////////////////////////////////////////////////////////////


  BT = new Bluetoothbutton(1750, 50, BT_count, BTdevices);  // setting up bluethoot menu

  COM_strings[0] = "COM101";
  COM_strings[1] = "COM5";
  COM_strings[2] = "COM03";

  BTdevices[0] = "Home Table";
  BTdevices[1] = "Bed";
  BTdevices[2] = "All";
  Devices_connected[0] = false;
  Devices_connected[1] = false;
  Devices_connected[2] = false;
  //Sending = new Serial(this,"COM4", 9600);
  connect_function();
      int[] xd = {6};
    int local_shit = sending_function(xd);
}


public void connect_function() {//connect funkce
  // funkce pro pripojeni kdyz v dosahu
  //dodelat COMy a vyzkouset naraz, zaroven probarvovat a odbarvovat prubezne kontrola
  COMS = Serial.list();
  printArray(COMS);
  for (int i = 0; i<COMS.length; i++) {
    for (int ii = 0; ii<COM_strings.length; ii++) {

      if (COMS[i].contains(COM_strings[ii])) {
        BT_availables[ii] = 1;
        index_c = ii;
        count_connected++;
      } else {
        BT_availables[ii] = 0;
      }
    }//mynysek je nejlepsi
  }
  if (count_connected == 1) {
    Sending = new Serial(this, COM_strings[index_c], 9600);
    BT_connected = true;
  } else {
    BT_connected = false;
  }
}
public int sending_function(int []sending_int) {
  String string = "<";
  for (int i = 0; i<sending_int.length; i++) {
    if (i == sending_int.length-1) {
      string = string + str(sending_int[i]);
    } else {        
      string = string  + str(sending_int[i]) + ",";
    }
  }
  string = string + ">";
  println(string);
  if (BT_connected == true) {
    Sending.write(string);
    return 1;
  } else {
    return 0;
  }
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////      DRAW      ////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

public void draw() {
  background(175, 175, 175);

  draw_led_function(ledred, ledgreen, ledblue);// vykresleni led

  // prepocitavani rgb do color tlacitka
  r = (r1 >> 16) & 0xFF;  // Very fast to calculate
  g = r1 >> 8 & 0xFF;  // Very fast to calculate
  b = r1 & 0xFF;  // Very fast to calculate
  r2=round(r)+", "+round(g)+", "+round(b);

  //vykresleni tlacitek
  draw_buttons();


  if (clicked) {
    if (mouseX>colorbuttonx && mouseX <colorbuttonx+colorbuttonw && mouseY>colorbuttony && mouseY <colorbuttony+colorbuttonh) {
      delay(100);
      int bytes[]={(byte)r, (byte)g, (byte)b};

      Sending.write(PApplet.parseByte(bytes));
    }
  }
  stroke(125);
  textAlign(CENTER, CENTER);
  textFont(titlefont);
  text("BLUE LED", 800, 50); 
  clicked = false;
  keypressed = false;
}




public void mouseClicked() { 
  clicked = true;
}




public void   Deff_buttons() {
  //volani instanci
  lumos_button= new lumos_button (50, 150, 200, 60, 255, 255, 255, 1);
  nox_button= new nox_button (50, 250, 200, 60, 0, 0, 0, 0);
  //opravit Button, predelat hodnoty RGB do funkce draw, abych mohl menit button barva
  barva = new Button (colorbuttonx, colorbuttony, colorbuttonw, colorbuttonh, 2);
  ruzova = new Button (350, 150, 200, 60, 6);
  zluta = new Button (350, 250, 200, 60, 7);
  fialova = new Button (600, 150, 200, 60, 8);
  oranzova = new Button (600, 250, 200, 60, 9);
  modra = new Button (850, 150, 200, 60, 5);
  cervena = new Button (850, 250, 200, 60, 3);
  cyan = new Button (1100, 150, 200, 60, 10);
  zelena = new Button (1100, 250, 200, 60, 4);
  hneda= new Button (1350, 150, 200, 60, 11);
  bila = new Button (1350, 250, 200, 60, 12);
  maroon= new Button (1600, 150, 200, 60, 13);
  golden = new Button (1600, 250, 200, 60, 14); 
  String [] rs = {"Delay"};
  int [] ri = {15, 0};
  Rainbow= new Button_mode (450, 650, 200, 60, 15);
  ri[1] = 16;
  Fade= new button_modes (450, 750, 200, 60, rs, ri);
  CylonBounce= new Button_mode (450, 850, 200, 60, 17);
  RunningLights = new Button_mode (450, 950, 200, 60, 18);   
  theaterChase = new Button_mode (675, 650, 200, 60, 19); 
  meteorRain = new Button_mode (675, 750, 200, 60, 20);
  Fillin_lane = new Button_mode (675, 850, 200, 60, 21);
  Mode3 = new Button_mode (675, 950, 200, 60, 19);
  Music1 = new Button_mode (500, 650, 200, 60, 19);
  Music2 = new Button_mode (500, 750, 200, 60, 19);
  Music3 = new Button_mode (500, 850, 200, 60, 19);
  Minus = new Button_mode (50, 350, 200, 60, 4);
  Plus = new Button_mode (50, 450, 200, 60, 3);
}
public void   draw_buttons() {
  //vykesleni tlacitek
  lumos_button.Draw("Lumos");
  nox_button.Draw("Nox");
  barva.Draw(r2, r, g, b);
  ruzova.Draw("Pink", 255, 105, 180);
  zluta.Draw("Yellow", 255, 255, 0);
  oranzova.Draw("Orange", 255, 127, 80);
  fialova.Draw("Purple", 128, 0, 128);
  modra.Draw("Blue", 0, 0, 255);
  cervena.Draw("Red", 255, 0, 0);
  cyan.Draw("Cyan", 0, 255, 255);
  zelena.Draw("Green", 0, 255, 0);
  hneda.Draw("Brown", 165, 42, 42);
  bila.Draw("White", 255, 255, 255);
  maroon.Draw("Maroon", 128, 0, 0);
  golden.Draw("Gold", 255, 215, 0);
  //  Rainbow.Draw("Rainbow");
  Fade.Draw("Fade"); 
  Rainbow.Draw("Rainbow", 218, 218, 218);
  //Fade.Draw("Fade", 218, 218, 218); 
  CylonBounce.Draw("Bounce", 218, 218, 218);
  RunningLights.Draw("Running Lights", 218, 218, 218);
  theaterChase.Draw("Chase", 218, 218, 218); 
  meteorRain.Draw("Meteor", 218, 218, 218);
  Minus.Draw("Minus", 218, 218, 218);
  Plus.Draw("Plus", 218, 218, 218);
  BT.Draw();
  Fillin_lane.Draw("Fill lane", 218, 218, 218);
  //Mode3.Draw("Mode 3");
  // Music1.Draw("Music 1");Music2.Draw("Music 2");Music3.Draw("Music 3");
}

class Bluetoothbutton {
  String label, Names [], label1, label2, label_C;
  float x;    // top left corner x position
  float y;    // top left corner y position
  float w;    // width of button
  float h;    // height of button
  PFont buttonfont;
  int a, c, red, green, blue;
  float  number_of_devices, wvyber, xvyber;
  boolean puvodni = true, vyber = false;
  float cc, ccc;




  Bluetoothbutton(float xpos, float ypos, float num, String[] names) {

    x = xpos;
    y = ypos;
    w = 150;
    h = 50;
    buttonfont = loadFont("AgencyFB-Bold-40.vlw");
    a = 0;
    b = 0;
    red = 0;
    green = 0;
    blue = 255;
    label1 = "Connected";
    label2 = "Not Connected";
    label_C = label2;
    label = "Connect";
    Names = names;
    number_of_devices = num;
    xvyber = x-number_of_devices*150+w;
    wvyber = number_of_devices*150;
    cc = 255;
    ccc = 0;
  }

  public void Draw() {
    if (BT_connected) {
      label_C = label1;
      cc = 0;
      ccc = 255;
      label = BTdevices[index_c];
    } else {
      label_C = label2;
      cc = 255;
      ccc = 0;
    }
    textFont(buttonfont, 30);
    textAlign(CENTER, CENTER);
    fill(0);
    for (int o = -1; o < 4; o++) {
      text(    label_C, x + (w / 2)+o, y -20);
      text(label_C, x + (w / 2), y -20+o);
    }
    fill(cc, ccc, 0);
    textFont(buttonfont, 30);
    text(label_C, x + (w / 2), y -20);
    if (puvodni) {
      fill(red, green, blue);
      stroke(a);
      rect(x, y, w, h, 10);
      textAlign(CENTER, CENTER);
      fill(255);
      textFont(buttonfont, 25);
      text(label, x + (w / 2), y + (h / 2));

      if (mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h) {
        a = 255;
      } else { 
        a =0;
      }        // nastavuje se ohraniceni kdyz prejedes mysi pro puvodni
    }
    if (vyber) {
      fill(0, 0, 255);
      stroke(0);
      rect(xvyber, y, wvyber, h+10, 10);
      for (int i = 0; i<number_of_devices; i++) {                                   // vykresli ctverce s volbama
        fill(255, 255, 255);
        stroke(a);
        rect(xvyber+10+i*150, y+5, 125, 50, 10);
        textAlign(CENTER, CENTER);
        fill(c);
        textFont(buttonfont, 25);
        text(Names[i], xvyber+10+i*150 + (125 / 2), y+5 + (50 / 2));
      }
      for (int i = 0; i<number_of_devices; i++) {
        if (mouseX>xvyber+10+i*150 && mouseX <xvyber+10+i*150+125 && mouseY>y+5 && mouseY <y+5+50) {
          a = 255;
        } else { 
          a =0;
        }
      }                                                // nastavuje se ohraniceni kdyz prejedes mysi pro vyber
    }

    if (clicked) {
      if (puvodni) {
        if (mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h) {
          vyber = true; 
          puvodni = false;
        }
      } else if (vyber) {
        for (int i = 0; i<number_of_devices; i++) {
          if (mouseX>xvyber+10+i*150 && mouseX <xvyber+10+i*150+125 && mouseY>y+5 && mouseY <y+5+50) {
            vyber = false;
            puvodni = true; 
            Devices_connected [i] = true;
            for (int y = 0; y< number_of_devices; y++) {
              if (y!=i) {
                Devices_connected[y] = false;
              }
            }                                // for loop to resetnuti vsech ostatnich na false
            TableConnected=Devices_connected[0];
            BedConnected=Devices_connected[1];
            AllConnected=Devices_connected[2];    // prepisuje do globalnich neznamych  
            label = Names[i];
            break;
          }
        }
      }
     // printArray(Devices_connected);
    }
  }
}

class Num_input {
  float x;    // top left corner x position
  float y;    // top left corner y position
  float w;    // width of button
  float h;    // height of button
  String input; // input number
  float a; //strokecolor
  float x1;
  boolean input_now = false;

  String str_num = "";
  String next_input = "";
  PFont buttonfont;

  Num_input(float xpos, float ypos, float wi, float he) {
    x1 = xpos;

    y = ypos;
    w = wi;
    h = he;
    a = 0;
    buttonfont = loadFont("AgencyFB-Bold-40.vlw");
  }

  public void Draw(int number, String nam) {
    float nam_w = textWidth(nam);
    x = nam_w+x1+10;
    textAlign(LEFT, CENTER);
    fill(255);
    textFont(buttonfont, 25); //pred tlacitkem string
    text(nam, x1+10, y + (h / 2));
    fill(125);
    stroke(a);
    rect(x, y, w+10, h, 10); //input rect
    textAlign(CENTER, CENTER);
    fill(255);
    textFont(buttonfont, 35);
    text(str_num, x + (w / 2), y + (h / 2)); //input string
    number = PApplet.parseInt(str_num);
    //println( number );
    if (clicked) {

      if (mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h) {
        input_now = true;
        str_num = "";
        a=255;
      } else {
        a=0;
        input_now = false;
      }
    }
    if (keypressed) {
      if (input_now) {
        if ( key >= '0' && key <= '9' ) {
          str_num += key;
        }else if(key == BACKSPACE){
          str_num = str_num.substring(0,str_num.length()-1);
        }
      }
    }
  }
}
class arcrg { //<>//
float x;
float y;
float w;
float h;
float l1;
float l2;
float rf;
float rs;
float speed = 0.08f;
float wait = 0;
boolean blink = false;



  arcrg( float x1, float y1, float w1, float h1, float f1, float f2) {
    x = x1;
    y = y1;
    w = w1;
    h = h1;
    l1 = f1;
    l2 = f1;
    rs = f1;
    rf = f2;

  }
  
  public void update(){
    
        if(l1<rf){
     l1 = l1 + speed; 
    }else if(wait < 100){
        if(wait == 50 || wait == 51){
         strokeWeight(10);
        }
      wait++;
      }else if(l2<rf){
       
     l2 = l2 + speed; 
    }else{
     l1 = rs;
     l2 = rs;
     wait = 0;
      
    }
    arcr(x,y,w,h,l2,l1, blink);
    blink = false;
    strokeWeight(5);
  }
}

class Button {
  String label;
  float x;    // top left corner x position
  float y;    // top left corner y position
  float w;    // width of button
  float h;    // height of button
  PFont buttonfont;
  int s; //sends
  int a, c, red, green, blue, c1, c2, red1, green1, blue1;
  int sending_return;




  Button(float xpos, float ypos, float widthB, float heightB, int send) {

    x = xpos;
    y = ypos;
    w = widthB;
    h = heightB;
    buttonfont = loadFont("AgencyFB-Bold-40.vlw");
    s = send;
    a = 0;
    b = 0;
    c1=c2=c;
  }

  public void Draw(String label, int re, int gr, int bl) {
    red = re;
    green = gr;
    blue = bl;
    red1 = re;
    green1 = gr;
    blue1 = bl;

    fill(red, green, blue);
    stroke(a);
    rect(x, y, w, h, 10);
    textAlign(CENTER, CENTER);
    fill(c, c1, c2);
    textFont(buttonfont, 35);
    text(label, x + (w / 2), y + (h / 2));


    if (clicked) {
      if (mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h) {
        if (BT_connected){
        a=255;
        int [] send_int = new int[4];
        send_int[0] = 2;
        send_int[1] = red1;
        send_int[2] = green1;
        send_int[3] = blue1;      
        ledred = red1;
        ledgreen = green1;
        ledblue = blue1;
        sending_return = sending_function(send_int);
      }else {
        not_con_function();
      }
    } else {
      a=0;
    }
    }
    if (mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h) {
      if (red == 255 && green == 255 && blue == 255) {
        c=255;
        c1=0;
        c2=0;
      } else {
        c=c1=c2=255;
      }
    } else {
      c=c1=c2=0;
    }
  
  /*
  void sending_function() {
   String string;
   string = "<"+str(2)+","+str(red1) + "," + str(green1) + "," + str(blue1) + ">";
   println(string);
   if (TableConnected == true) {
   table.write(string);
   } else if (BedConnected == true) { 
   bed.write(string);
   } else if (AllConnected == true) {
   bed.write(string);
   table.write(string);
   } else {
   stroke(255, 0, 0);
   fill(255, 0, 0);
   rect(x, y, w, h, 10);
   }
   }
   */
}
}
public void not_con_function(){
}

class Button_mode {
  String label;
  float x;    // top left corner x position
  float y;    // top left corner y position
  float w;    // width of button
  float h;    // height of button
  PFont buttonfont;
  int s; //sends
  int a, c, red, green, blue, c1, c2, red1, green1, blue1;
  int sending_return;




  Button_mode(float xpos, float ypos, float widthB, float heightB, int send) {

    x = xpos;
    y = ypos;
    w = widthB;
    h = heightB;
    buttonfont = loadFont("AgencyFB-Bold-40.vlw");
    s = send;
    a = 0;
    b = 0;
    c1=c2=c;
    s= send;
  }

  public void Draw(String label, int re, int gr, int bl) {
    red = re;
    green = gr;
    blue = bl;
    red1 = re;
    green1 = gr;
    blue1 = bl;

    fill(red, green, blue);
    stroke(a);
    rect(x, y, w, h, 10);
    textAlign(CENTER, CENTER);
    fill(c, c1, c2);
    textFont(buttonfont, 35);
    text(label, x + (w / 2), y + (h / 2));


    if (clicked) {
      if (mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h) {
        if (BT_connected) {
          a=255;
          int [] send_int = new int[3];
          send_int[0] = s;
          /*
          dodelat array of sending
           send_int[0] = red1;
           send_int[1] = green1;
           send_int[2] = blue1;
           */
          sending_return = sending_function(send_int);
        } else {
          not_con_function();
        }
      }
    } else {
      a=0;
    }
    if (mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h) {
      if (red == 255 && green == 255 && blue == 255) {
        c=255;
        c1=0;
        c2=0;
      } else {
        c=c1=c2=255;
      }
    } else {
      c=c1=c2=0;
    }
  }
}

class button_modes {
  String label;
  float x;    // top left corner x position
  float y;    // top left corner y position
  float w;    // width of button
  float h;    // height of button
  PFont buttonfont;
  int a, c, red, green, blue, c1, c2, red1, green1, blue1;
  String names[];
  boolean first = true, popup = false, all_inputs = false, warnings =false;
  float  xpop, wpop;
  int [] sends;
  Num_input[] inputs; // tady musim preddefinovat ze budu chtit zavolat instanci (snad to rikam dobre
  float stringwidth = 0; // jak dlouhe jsou jmena v inputu
  float mezera = 5;
  float input_w = 40;


  button_modes(float xpos, float ypos, float widthB, float heightB, String[] n, int[]send) {    
    float wi = 0;
    x = xpos;
    y = ypos;
    w = widthB;
    h = heightB;
    buttonfont = loadFont("AgencyFB-Bold-40.vlw");
    a = 0;
    c1=c2=c;
    xpop = x-mezera;
    names = n;
    inputs = new Num_input[names.length]; 
    for (int i = 0; i< names.length; i++) { // tady bych chtel vytvorit moje ovoce do obchodu
      wi = textWidth(names[i]);
      //println(wi);
      inputs[i] =  new Num_input(xpop+mezera+i*(input_w+mezera+50), y, input_w, h);
      stringwidth = stringwidth + wi;
    }
    wpop = names.length*input_w+(names.length+1)*mezera+stringwidth+names.length*25;
    sends = send;
  }

  public void Draw(String label) {
    if (first) {

      fill(125);
      stroke(a);
      rect(x, y, w, h, 10);//prvni tlacitko
      textAlign(CENTER, CENTER);
      fill(c, c1, c2);
      textFont(buttonfont, 35);// text k prvnimu tlacitku
      text(label, x + (w / 2), y + (h / 2));
    }
    if (popup) {
      fill(218,218,218, 50);
      stroke(0);
      rect(xpop, y-5, wpop+20, h+10, 10);
      for (int i = 0; i< names.length; i++) {

        inputs[i].Draw(sends[i], names[i]); //vykresluje inputove tlacitka
      }
    }
    if (clicked) {
      if (first && button_menu == false) {//otevria popup menu, pokud neni otevrene a neni otevrene jine
        if (mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h) { // pokud klikne na tlacitko
            popup = true;
            first = false;
            button_menu = true;
          }
        } else if(popup){//zavira popup menu
             if (mouseX>xpop && mouseX <xpop+wpop && mouseY>y - 5 && mouseY <y + h + 5) { // pokud klikne na popup menu // -5+10=+5
             }else{
            popup = false;
            first = true;
            button_menu = false;
             }
          }
    }
    //konci click event
    if (mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h) {
      c=255;
      c1=0;
      c2=0;
    } else {
      c=c1=c2=255;
    }
  }
  public String getMyName() {
    if (popup) {
      return this.getClass().getName();
    } else {
      return "";
    }
  }
}
class linerg { //<>// //<>//
  float distance;
  float [] x1x2 = new float [2];
  float y_start;
  float y_end;
  float xl, yl;
  float wait = 0;
  boolean x_true, y_true, doo = true;
  boolean xvetsi = false, xmensi = false, yvetsi = false, ymensi = false;
  linerg( float x, float y, float x2, float y2) {
    
    if (x == x2) {
      xl  = x;
      x_true = true;
      if (y>y2) {
        yvetsi = true;
        x1x2[0] = y2;
        x1x2[1] = y;
        y_start = y;
        y_end = y2;
      } else {
        ymensi = true;
        x1x2[0] = y;
        x1x2[1] = y2;
        y_start = y;
        y_end = y2;
      }
    } else if (y ==y2) {
      yl = y;
      y_true = true;
      if (x>x2) {
        xvetsi = true;
        x1x2[0] = x2;
        x1x2[1] = x;
        y_start = x2;
        y_end = x;
      } else {
        xmensi = true;
        x1x2[0] = x2;
        x1x2[1] = x;
        y_start = x2;
        y_end = x;
      }
    }
  }
  public void update() {
    if (doo) {
      x1x2 = smooth_line(x1x2[0], x1x2[1], y_start, y_end);
    }
    if ((x1x2[0] < y_end + 10 && x1x2[1] == y_start && xmensi)||(x1x2[0] > y_end - 10 && x1x2[1] == y_start && ymensi)||(x1x2[0] < y_end + 10 && x1x2[1] == y_start && yvetsi) ||(x1x2[0] > y_end - 10 && x1x2[1] == y_start && xvetsi)) { 
      doo = false;
      if (wait<100) {
        wait++;
      } else {
        wait = 0;
        doo = true;
      }
    }

    if (x_true) {
      liner(xl, x1x2[0], xl, x1x2[1]);
    } else if (y_true) {
      liner(x1x2[0], yl, x1x2[1], yl);
    }
  }
}
public float[] smooth_line(float y_first, float y_second, float ys, float ye) {
  float yt;
  float sped = 0.1f;
  float[] return_array = new float[2];
  if (ys >ye) {
    yt = ye + 10;
    if (y_first>yt) {
      y_first = lerp(y_first, ye, 0.1f );
    } else if (y_second>yt) {
      y_second = lerp(y_second, ye, 0.1f);
    } else {
      y_first = ys;
      y_second = ys;
    }
  } else {
    yt = ye - 10;
    if (y_first<yt) {
      y_first = lerp(y_first, ye, sped );
    } else if (y_second<yt) {
      y_second = lerp(y_second, ye, sped);
    } else {

      y_first = ys;
      y_second = ys;
    }
  }

  return_array[0] = y_first;
  return_array[1] = y_second;
  return return_array;
}
public void set_draw_led(float x, float y, float tr){
  float t = tr;
  line1 = new linerg(x, y-20*t, x, y-200*t);
  line2 = new linerg(x+300*t, y-180*t, x+300*t, y);
  line3 = new linerg(x-50*t, y, x+350*t, y);
  line4 = new linerg( x+350*t, y+50*t, x-50*t, y+50*t);
  line5 = new linerg(x+350*t, y+50*t, x+350*t, y);
  line6 = new linerg(x-50*t, y, x-50*t, y+50*t);
  line7 = new linerg(x+225*t, y+70*t, x+225*t, y+150*t);
  line8 = new linerg(x+125*t, y+70*t, x+125*t, y+250*t);
  arc1 = new arcrg(x + 150*t, y-200*t, 300*t, 300*t, PI, 2*PI);
}


public void   draw_led_function(int rr, int gg, int bb) {

  SetRGB(rr, gg, bb);
  //arcr(x + 150, y-200, 300, 300, PI, 2*PI);
  arc1.update();
  line1.update();   
  line2.update(); 
  line3.update();
  line4.update();
  line5.update();
  line6.update(); 
  line7.update();
  line8.update();

}


public void liner (float x1, float y1, float x2, float y2) {
  float xs, ys, xn, yn;
  float delka;
  if (abs(PApplet.parseInt(x1)-PApplet.parseInt(x2)) > abs(PApplet.parseInt(y2)-PApplet.parseInt(y1))) {
    delka = abs(PApplet.parseInt(x1)-PApplet.parseInt(x2));
  } else {
    delka = abs(PApplet.parseInt(y2)-PApplet.parseInt(y1));
  }
  xs = x1; 
  ys = y1;
  for (int i = 1; i<=delka; i++) {
    //changecolor(1);
    xn = lerp(x1, x2, i/delka); 
    yn = lerp(y1, y2, i/delka);
    //println(xn,yn);
    //xn = xs;
    //yn = ys+1;
    //println(r,g,b);
    strokeWeight(5);
    stroke(red, green, blue);
    line (xs, ys, xn, yn);
    /*
    strokeWeight(1);
     stroke(255);
     line (xs+5, ys, xn, yn);
     stroke(255);
     line (xs-5, ys, xn, yn);
     strokeWeight(10);
     */
    xs = xn; 
    ys = yn;
  }
}

public void SetRGB(int r, int g, int b) {
  red = r;
  green = g;
  blue = b;
}


public void changecolor( int step) {
  if (rr) {
    if (red!=0) {
      red = red -  step;
      green = green+step;
    } else {
      gg = true; 
      rr = false;
    }
  }
  if (gg) {
    if (green!=0) {
      green = green -  step;
      blue = blue+step;
    } else {
      bb = true; 
      gg = false;
    }
  }
  if (bb) {
    if (blue!=0) {
      blue = blue -  step;
      red = red+step;
    } else {
      rr = true; 
      bb
      = false;
    }
  }
  //  println(red);
  //  println(green);
  //  println(blue);
}


public void arcr(float x, float y, float w, float h, float f1, float f2, boolean b) {
  float delka = abs(f2-f1)/0.01f;
  float fs = f1;
  float fe;
  for (int i = 1; i<=delka; i++) {
    // changecolor(1);
    fe =fs +0.01f;
    noFill();
    if (b){
      stroke (255,255,0);
      
    }else{
      
    stroke(red, green, blue);
    }
    arc(x, y, w, h, fs, fe);
    fs = fe;
  }
}
/*
  arcr(x + 150, y-200, 300, 300, PI, 2*PI);
 liner(x+300, y, x+300, y-200);
 liner(x+350, y, x-50, y);
 liner(x+350, y+50, x-50, y+50);
 liner(x+350, y, x+350, y+50);
 liner(x-50, y, x-50, y+50);
 liner(x+225, y+50, x+225, y+150);
 liner(x+75, y+50, x+75, y+250);
 */

class lumos_button {
  String label;
  float x;    // top left corner x position
  float y;    // top left corner y position
  float w;    // width of button
  float h;    // height of button
  PFont buttonfont;
  float s; //sends
  int a, c, red, green, blue, red1, green1, blue1;
  int sending_return;




  lumos_button(float xpos, float ypos, float widthB, float heightB, int re, int gr, int bl, float send) {

    x = xpos;
    y = ypos;
    w = widthB;
    h = heightB;
    buttonfont = loadFont("AgencyFB-Bold-40.vlw");
    s = send;
    a = 0;
    b = 0;
    red = re;
    green = gr;
    blue = bl;
    red1 = re;
    green1 = gr;
    blue1 = bl;
  }

  public void Draw(String label) {
    fill(red, green, blue);
    stroke(a);
    rect(x, y, w, h, 10);
    textAlign(CENTER, CENTER);
    fill(c);
    textFont(buttonfont, 35);
    text(label, x + (w / 2), y + (h / 2));


    if (clicked) {
      if (mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h) {
        if (BT_connected){
        a=255;
        int [] send_int = new int[1];
        send_int[0] = 1;
        sending_return = sending_function(send_int);
      }else {
        not_con_function();
      }
    }
    } else {
      a=0;
    }
    if (mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h) {
      c=255;
      red=0;
      green=0;
      blue=0;
    } else {
      c=0;
      red=255;
      green=255;
      blue=255;
    }
  }  
}

class nox_button {
  String label;
  float x;    // top left corner x position
  float y;    // top left corner y position
  float w;    // width of button
  float h;    // height of button
  PFont buttonfont;
  float s; //sends
  int a, c, red, green, blue;
  int sending_return;



  nox_button(float xpos, float ypos, float widthB, float heightB, int re, int gr, int bl, float send) {

    x = xpos;
    y = ypos;
    w = widthB;
    h = heightB;
    buttonfont = loadFont("AgencyFB-Bold-40.vlw");
    s = send;
    a = 255;
    b = 0;
    red = re;
    green = gr;
    blue = bl;
  }

  public void Draw(String label) {
    fill(red, green, blue);
    stroke(a);
    rect(x, y, w, h, 10);
    textAlign(CENTER, CENTER);
    fill(c);
    textFont(buttonfont, 35);
    text(label, x + (w / 2), y + (h / 2));


    if (clicked) {
      if (mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h) {
        if (BT_connected){
        a=255;
        int [] send_int = new int[1];
        send_int[0] = 0;
        sending_return = sending_function(send_int);
      }else {
        not_con_function();
      }
    }
    } else {
      a=255;
    }
    if (mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h) {
      c=0;
      red=255;
      green=255;
      blue=255;
    } else {
      c=255;
      red=0;
      green=0;
      blue=0;
    }
  }
  /*
  void sending_function() {
    String string;
    string = "<"+str(0) + ">";
    if (BT_connected == true) {
      Sending.write(string);

    } else {
      stroke(255, 0, 0);
      fill(255, 0, 0);
      rect(x, y, w, h, 10);
    }
  }
  */
  /*
    void sending_function() {
    String string;
    string = "<"+str(0) + ">";
    if (TableConnected == true) {
      table.write(string);
    } else if (BedConnected == true) { 
      bed.write(string);
    } else if (AllConnected == true) {
      bed.write(string);
      table.write(string);
    } else {
      stroke(255, 0, 0);
      fill(255, 0, 0);
      rect(x, y, w, h, 10);
    }
  }
  */
}   
  public void settings() {  size(1920, 1080); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "BlueLed_v1" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
