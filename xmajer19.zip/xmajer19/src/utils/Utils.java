package utils;

import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.Parent;
import store.Item;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Class containing widely utilized methods throughout the project
 */
public class Utils {

    public Utils() {
        throw new RuntimeException("I am a utils.Utils class");
    }

    /**
     * Method for parsing initial content and orders to a hashmap with names and counts of items
     * @param lines Strings representing item names and counts
     * @return parsed items
     */
    public static HashMap<String, Integer> parseStoreItems(ArrayList<String> lines) {
        HashMap<String, Integer> items = new HashMap<>();
        for (String line : lines) {
            String[] parts = line.split(" ");
            String goodsName = String.join(" ", parts[0].split("_"));
            int itemCount = Integer.parseInt(parts[1]);
            items.put(goodsName, itemCount);
        }
        return items;
    }
    public static ObservableList<Item> parseStoreItems_vol2(ArrayList<String> lines) {
        ObservableList<Item> items = FXCollections.observableArrayList();
        for (String line : lines) {
            String[] parts = line.split(" ");
            String goodsName = String.join(" ", parts[0].split("_"));
            int itemCount = Integer.parseInt(parts[1]);
            int itemWeight = Integer.parseInt(parts[2]);
            Item item = new Item(goodsName,itemCount,itemWeight);
            items.add(item);
        }
        return items;
    }

    public static ArrayList<Node> getAllNodes(Parent root) {
        ArrayList<Node> nodes = new ArrayList<Node>();
        addAllDescendents(root, nodes);
        return nodes;
    }

    private static void addAllDescendents(Parent parent, ArrayList<Node> nodes) {
        for (Node node : parent.getChildrenUnmodifiable()) {
            nodes.add(node);
            if (node instanceof Parent)
                addAllDescendents((Parent)node, nodes);
        }
    }

}
