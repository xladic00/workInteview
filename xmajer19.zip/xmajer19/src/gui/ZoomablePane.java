package gui;

import javafx.scene.Group;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.StackPane;

/**
 * new class for implementing zooming ability
 */
class ZoomablePane extends StackPane {

    final double SCALE_DELTA = 1.2;

    public Group content = new Group();

    public ZoomablePane() {
        super();
        getChildren().add(content);
        content.setAutoSizeChildren(true);
        setOnScroll((ScrollEvent event) -> {
            event.consume();
            if (event.getDeltaY() == 0) {
                return;
            }

            double scaleFactor
                    = (event.getDeltaY() > 0)
                    ? SCALE_DELTA
                    : 1 / SCALE_DELTA;


            content.setScaleX(content.getScaleX() * scaleFactor);
            content.setScaleY(content.getScaleY() * scaleFactor);
        });
    }

}