package gui;

import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.StrokeType;
import javafx.scene.text.Font;
import javafx.stage.Popup;
import javafx.stage.Stage;
import store.Item;
import store.StoreShelf;

import java.util.ArrayList;

public class GShelf {

    private final Rectangle rect;
    private boolean selected;
    private final Label label;
    private final GWarehouse warehouse;
    final float width;
    final float height;
    private final StoreShelf shelf;
    private StackPane stack;

    /**
     * his class implements GUI representation of StoreShelf
     * @param shelf connecting this with specific StoreShelf
     * @param numberOfShelf showing the number of this GShelf
     * @param gWarehouse main GUI
     */
    public GShelf(StoreShelf shelf, int numberOfShelf, GWarehouse gWarehouse) {

        this.stack = new StackPane();
        this.shelf = shelf;
        width = 30;
        height = 30;
        label = new Label();
        label.setTextFill(Color.BLUE);
        label.setFont(new Font("Arial",10));
        label.setText(Integer.toString(numberOfShelf));
        this.selected = false;
        this.warehouse = gWarehouse;
        rect = new Rectangle(width,height);
        EventHandler<MouseEvent> clickedHandler = ev -> {
            gWarehouse.setSelectedShelf(this);
            ev.consume();
        };

        rect.setStrokeWidth(2);
        rect.setStrokeType(StrokeType.INSIDE);
        rect.setStroke(Color.WHITE);
        rect.setFill(Color.HOTPINK);
        stack.setOnMouseClicked(clickedHandler);
        stack.getChildren().addAll(rect, label);
        shelf.getMyGShelf(this);
    }
    public Node getGridImports(){
        return stack;
    }

    public void selected(boolean b) {
        selected = b;
        if (selected) {
            rect.setFill(Color.GREEN);
            Point2D p = rect.localToScreen(rect.getLayoutX(), rect.getLayoutY());
            display(shelf.getGoods(), warehouse.getStage(),p.getX() + 30,p.getY());
        }
        else {
            rect.setFill(Color.HOTPINK);
        }
    }

    /**
     * This function create Popup with informations about the content of this shelf
     * @param items content of shelf
     * @param stage stage to show the Popup
     * @param x X coordinate where to show the Popup
     * @param y Y coordinate where to show the Popup
     */
    public static void display(ArrayList<Item> items, Stage stage, Double x, Double y) {

        BackgroundFill background_fill = new BackgroundFill(Color.BEIGE,
                CornerRadii.EMPTY, Insets.EMPTY);
        Background background = new Background(background_fill);

        StackPane stack = new StackPane();

        Popup popup = new Popup();
        popup.setAutoHide(true);
        popup.setAnchorX(x);
        popup.setAnchorY(y);

        VBox layout1 = new VBox(10);
        layout1.getChildren().add(new Label("Items"));
        layout1.setSpacing(10);
        VBox layout2 = new VBox(10);
        layout2.getChildren().add(new Label("Count"));
        layout2.setSpacing(10);
        VBox layout3 = new VBox(10);
        layout3.getChildren().add(new Label("Weight"));
        layout3.setSpacing(10);

        if (items.size() != 0) {
            for (Item item : items) {
                Label labelItemName = new Label(item.getItemName());
                layout1.getChildren().add(labelItemName);

                Label labelItemCount = new Label(String.valueOf(item.getCount()));
                layout2.getChildren().add(labelItemCount);

                Label labelItemWeight = new Label(String.valueOf(item.getItemWeight()));
                layout3.getChildren().add(labelItemWeight);
            }
        } else {
            Label nothing = new Label("NOTHING HERE");
            layout1.getChildren().add(nothing);
        }

        HBox layout = new HBox();
        layout.getChildren().addAll(layout1, layout2, layout3);
        layout.setSpacing(10);
        layout.setPadding(new Insets(10,10,10,10));
        layout.setAlignment(Pos.CENTER);

        layout.setBackground(background);
        stack.getChildren().add(layout);
        popup.getContent().add(stack);

        popup.show(stage);
        popup.hide();
        Rectangle stroke = new Rectangle(layout.getWidth(), layout.getHeight());
        stroke.setFill(Color.TRANSPARENT);
        stroke.setStrokeWidth(2);
        stroke.setStroke(Color.BLACK);
        popup.getContent().add(stroke);
        popup.show(stage);
    }
}
