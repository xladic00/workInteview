package gui;

import enums.Rotation;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.PauseTransition;
import javafx.animation.Timeline;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import store.Item;
import store.StoreCart;
import store.Warehouse;
import java.io.*;
import java.util.ArrayList;
import static enums.TileType.*;

public class GWarehouse {

    private GShelf selectedShelf;
    private GCart selectedCart;
    private final ZoomablePane zoom;

    private Button pp;
    private final Warehouse model;
    private final GridPane grid;
    private final BorderPane borderpane;
    private final Stage stage;
    private TableView allItemsTable;
    private TableView cartTableView;
    private TableView orderTable;
    private boolean toggleBarricade = false;
    private ProgressBar pbBar;
    private boolean pausePlay = false;
    private final Label infoLabel;
    private final Label pausedLabel;

    private int hours = 0;
    private int minutes = 0;
    private double speed = 1000;
    Timeline timeline;
    private Label timer;
    Button fasterButton;
    Button slowerButton;
    private PauseTransition infoTimeline;

    /**
     * this class implements main class of this app Warehouse
     * @param model implementing owner Warehouse
     * @param stage main stage of warehouse GUI
     * @throws IOException invalid order file
     */
    public GWarehouse(Warehouse model, Stage stage) throws IOException {

        this.stage = stage;
        getTime(speed);
        borderpane = FXMLLoader.load(getClass().getResource("/gui/fxmlFile/mainscene.fxml"));

        infoLabel = (Label) borderpane.lookup("#infoLabel");
        pausedLabel = (Label) borderpane.lookup("#pausedLabel");
        infoTimeline = new PauseTransition();

        this.model = model;

        grid = new GridPane();

        BackgroundFill background_fill = new BackgroundFill(Color.BURLYWOOD, CornerRadii.EMPTY, Insets.EMPTY);
        BackgroundFill background_fill1 = new BackgroundFill(Color.GREY, CornerRadii.EMPTY, Insets.EMPTY);
        Background gridBackground = new Background(background_fill1);
        BackgroundFill background_fill2 = new BackgroundFill(Color.YELLOW, CornerRadii.EMPTY, Insets.EMPTY);
        Background background2 = new Background(background_fill);
        Background mainBackground = new Background(background_fill);

        grid.setAlignment(Pos.CENTER);

        int Count = 0;
        int CartNum = 0;
        for (int row = 0; row < model.getHeight(); row++) {
            for (int column = 0; column < model.getWidth(); column++) {
                if ((model.get(row, column).getType().equals(LOADING_ZONE))) {
                    Label label = new Label("L");
                    label.setTextFill(Color.WHITE);
                    label.setFont(new Font("Arial", 15));
                    GridPane.setHalignment(label, HPos.CENTER);
                    Rectangle rectLoad = new Rectangle(30, 30);
                    rectLoad.setFill(Color.BLACK);
                    grid.add(rectLoad, column, row);
                    grid.add(label, column, row);
                } else if (model.get(row, column).getType().equals(SHELF)) {
                    GShelf shelf = new GShelf(model.getShelves().get(Count), Count + 1, this);
                    grid.add(shelf.getGridImports(), column, row);
                    Count++;
                } else if (model.get(row, column).getType().equals(CART)) {
                    GCart cart = new GCart(model.getCarts().get(CartNum), grid, row, column,
                            CartNum + 1, this);
                    CartNum++;
                } else {
                    setInteractiveBackground(row, column);
                }
            }
        }
        setInfo("Warehouse contains " + model.getShelves().size() + " shelves, "
                + model.getCarts().size() + " carts and " + model.getItemsList().size() + " items.");

        grid.setOnMouseClicked(ev -> {
            setSelectedShelf(null);
            setSelectedCart(null);
        });

        zoom = new ZoomablePane();
        zoom.content.getChildren().add(grid);
        zoom.setBackground(gridBackground);
        zoom.setPrefWidth(300);

        borderpane.setCenter(zoom);

        VBox rightVBox = (VBox) borderpane.lookup("#rightVbox");
        rightVBox.setBackground(mainBackground);
        rightVBox.setViewOrder(-1);
        HBox topHBox = (HBox) borderpane.lookup("#topHbox");
        topHBox.setViewOrder(-1);
        topHBox.setBackground(mainBackground);
        HBox leftV = (HBox) borderpane.lookup("#leftV");
        leftV.setViewOrder(-1);
        leftV.setBackground(mainBackground);
        HBox botV = (HBox) borderpane.lookup("#botV");
        botV.setViewOrder(-1);
        botV.setBackground(mainBackground);

    }


    /**
     * adding Rectangles with events to main GridPane
     * this is used, when creating new Barricade
     * @param row
     * @param column
     */
    public void setInteractiveBackground(int row, int column) {

        Rectangle rect = new Rectangle(30, 30);
        rect.setViewOrder(-1);
        rect.setFill(Color.TRANSPARENT);
        rect.setOnMouseEntered(e -> {
            if (toggleBarricade) if (model.get(row, column).getType() != BARRICADE) {
                rect.setFill(Color.DARKSLATEGREY);
            }
        });
        rect.setOnMouseExited(e -> {
            if (toggleBarricade) if (model.get(row, column).getType() != BARRICADE) {
                rect.setFill(Color.TRANSPARENT);
            }
        });
        rect.setOnMouseClicked(e -> {
            if (!toggleBarricade) {
                return;
            }
            model.setBarricade(row, column);
            if (model.get(row, column).getType() != BARRICADE) {
                rect.setFill(Color.GREY);
                setInfo("Deleting barricade");
            } else {
                rect.setFill(Color.DARKSLATEGREY);
                setInfo("Making barricade");
            }
        });
        grid.add(rect, column, row);
    }

    public void setSelectedShelf(GShelf gShelf) {
        if (gShelf == null) {
            if (selectedShelf != null) {
                selectedShelf.selected(false);
                selectedShelf = null;
            }
        } else {
            if (selectedShelf != null) {
                if (selectedShelf == gShelf) {
                    selectedShelf.selected(false);
                    selectedShelf = null;
                } else {
                    selectedShelf.selected(false);
                    selectedShelf = gShelf;
                    selectedShelf.selected(true);
                }
            } else {
                selectedShelf = gShelf;
                selectedShelf.selected(true);
            }
        }
    }

    public void setSelectedCart(GCart gCart) {
        if (gCart == null) {
            if (selectedCart != null) {
                selectedCart.selected(false);
                selectedCart = null;
            }
        } else {
            if (selectedCart != null) {
                if (selectedCart == gCart) {
                    selectedCart.selected(false);
                    selectedCart = null;
                } else {
                    selectedCart.selected(false);
                    selectedCart = gCart;
                    selectedCart.selected(true);
                }
            } else {
                selectedCart = gCart;
                selectedCart.selected(true);
            }
        }
        if (selectedCart == null) {
            pbBar.setProgress(0);
            Label num = (Label) borderpane.lookup("#CartNumberLabel");
            num.setText(null);
            model.getSelectedOrderList().clear();

        } else {
            pbBar.setProgress(selectedCart.getAdded() / selectedCart.getOrderList().size());
            Label num = (Label) borderpane.lookup("#CartNumberLabel");
            num.setText(this.selectedCart.getNumber());
            model.setSetSelectedOrderList(this.selectedCart.getOrderList());
        }
    }

    /**
     * giving order to available StoreCart and proceeding to startOrder
     * orderingList from model is sorted, checked for items, that are blocked (these are removed)
     * skipped items are showed to user on left top corner
     */
    public void processOrder_vol2() {
        boolean cartAvailable = false;
        if (model.getOrderingList().size() != 0) {
            for (StoreCart avCart : model.getCarts()) {
                if (avCart.isAvailable()) {
                    cartAvailable = true;
                    if (model.getSkippedItems().size() > 0) {
                        String showSkipped = model.getSkippedItems().get(0).getItemName();
                        for (int index = 1; index < model.getSkippedItems().size(); index++) {
                            showSkipped = showSkipped + ", ";
                            showSkipped = showSkipped + model.getSkippedItems().get(index).getItemName();
                        }
                        setInfo("Skipped items: " + showSkipped);
                    }
                    avCart.setOrderList(model.getOrderingList());
                    model.sortOrderingList();
                    avCart.splitOrder();
                    avCart.startOrder();
                    break;
                }
            }
        } else {
            setInfo("Order is empty!!");
        }
        if (!cartAvailable) {
            setInfo("Next order will be waiting in queue");
            model.addToQueue();
        } else {
            allItemsTable.refresh();
            model.getOrderingList().clear();
        }
    }

    /**
     * this function finds all GUI controls and set their functions,
     * connect them with specific variables and set their events
     * @param scene scene that this GUI controls and container are shown on
     */
    public void setUp(Scene scene) {

        pbBar = (ProgressBar) scene.lookup("#cartProgressBar");

        fasterButton = (Button) scene.lookup("#fasterButton");
        fasterButton.setOnAction(e -> {
            for (StoreCart cart : model.getCarts()) {
                cart.fastRate();
            }
            faster();
            e.consume();
        });
        slowerButton = (Button) scene.lookup("#slowerButton");
        slowerButton.setOnAction(e -> {
            for (StoreCart cart : model.getCarts()) {
                cart.slowRate();
            }
            slower();
            e.consume();
        });

        Button orderButton = (Button) scene.lookup("#orderButton");
        orderButton.setOnAction(e -> this.processOrder_vol2());

        Button fileOrder = (Button) scene.lookup("#addToCartFileButton");
        fileOrder.setOnAction(e -> {
            FileChooser fc = new FileChooser();
            File selectedFile = fc.showOpenDialog(null);

            if (selectedFile != null) {
                try {
                    setOrderingListFromFile(selectedFile);
                } catch (IOException fileNotFoundException) {
                    fileNotFoundException.printStackTrace();
                }
            }
        });

        pp = (Button) scene.lookup("#pausePlayButton");
        pp.setOnAction(event -> pausePlay());

        ToggleButton barricade = (ToggleButton) scene.lookup("#toggleButton");
        barricade.setOnAction(e -> {
            toggleBarricade = !toggleBarricade;
            if (!toggleBarricade && model.getBarricadeCount() != model.getBarricadeCountLast()) {
                model.resetBarricadeCount();
//                reCalculatePaths();
            }
            pausePlay = !pausePlay;
            pausePlay();
        });

        Spinner<Integer> spinner = (Spinner<Integer>) scene.lookup("#intField");
        ComboBox chooseItemComboBox = (ComboBox) scene.lookup("#itemComboBox");
        chooseItemComboBox.getItems().addAll(model.getItemsNames());
        chooseItemComboBox.setVisibleRowCount(15);
        chooseItemComboBox.setOnAction(e -> {
            if (!(chooseItemComboBox.getValue() == null)) {
                if (model.getItemCount(String.valueOf(chooseItemComboBox.getValue())) > 0) {
                    SpinnerValueFactory<Integer> svf = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, model.getItemCount(String.valueOf(chooseItemComboBox.getValue())), 1);
                    spinner.setValueFactory(svf);
                } else {
                    spinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 0));
                    setInfo("Item is not in Stock!");
                }
            }
        });

        Button addToCart = (Button) scene.lookup("#addToCartButton");
        addToCart.setOnAction(e -> addToCart(chooseItemComboBox, spinner));

        TextField timeSetterHours = (TextField) scene.lookup("#timeSetterHours");
        TextField timeSetterMinutes = (TextField) scene.lookup("#timeSetterMinutes");
        HBox ttt = (HBox) scene.lookup("#ttt");
        timer = (Label) scene.lookup(("#timer"));
        timer.setOnMouseClicked(e -> {
            e.consume();
            ttt.setVisible(!ttt.isVisible());
            getTime(speed);
        });

        Button setterTime = (Button) scene.lookup("#setterTime");
        setterTime.setOnAction(e -> {
            e.consume();
            if (timeSetterHours.getText() != null && timeSetterMinutes.getText() != null
                    && isNumeric(timeSetterHours.getText()) && isNumeric(timeSetterMinutes.getText())
                    && Integer.parseInt(timeSetterHours.getText()) < 24 && Integer.parseInt(timeSetterHours.getText()) > -1
                    && Integer.parseInt(timeSetterMinutes.getText()) < 59 && Integer.parseInt(timeSetterMinutes.getText()) > -1)
            {
                    String string = timeSetterHours.getText() + " : " + timeSetterMinutes.getText();
                    timer.setText(string);
                    hours = Integer.parseInt(timeSetterHours.getText());
                    minutes = Integer.parseInt(timeSetterMinutes.getText());
                    getTime(speed);
                } else {
                    setInfo("Wrong Time format");
                }
                timeSetterHours.setText(null);
                timeSetterMinutes.setText(null);
                timeSetterHours.setPromptText("0");
                timeSetterMinutes.setPromptText("0");
                ttt.setVisible(false);
        });

        //TableView for all items in store
        allItemsTable = (TableView) scene.lookup("#ShelfTableView");
        TableColumn<Item, String> itemName = new TableColumn<>("Items");
        itemName.setCellValueFactory(new PropertyValueFactory<>("itemName"));
        TableColumn<Item, Integer> itemAmount = new TableColumn<>("Amount");
        itemAmount.setCellValueFactory(new PropertyValueFactory<>("count"));
        TableColumn<Item, Integer> itemWeight = new TableColumn<>("Weight");
        itemWeight.setCellValueFactory(new PropertyValueFactory<>("itemWeight"));
        allItemsTable.setItems(model.getItemsList());
        allItemsTable.getColumns().addAll(itemName, itemAmount, itemWeight);

        //TableView for all items in actual order process
        orderTable = (TableView) scene.lookup("#orderCartTable");
        TableColumn<Item, String> itemNameOrder = new TableColumn<>("Items");
        itemNameOrder.setCellValueFactory(new PropertyValueFactory<>("itemName"));
        TableColumn<Item, Integer> itemAmountOrder = new TableColumn<>("Amount");
        itemAmountOrder.setCellValueFactory(new PropertyValueFactory<>("count"));
        TableColumn<Item, Integer> itemWeightOrder = new TableColumn<>("Weight");
        itemWeightOrder.setCellValueFactory(new PropertyValueFactory<>("itemWeight"));
        orderTable.setItems(model.getOrderingList());
        orderTable.getColumns().addAll(itemNameOrder, itemAmountOrder, itemWeightOrder);

        Button deleteItem = (Button) scene.lookup("#deleteButton");

        deleteItem.setOnAction(e -> {
            Item item = (Item) orderTable.getSelectionModel().getSelectedItem();
            delItem(item);
            e.consume();
        });

        //TableView for all items in selected Cart
        cartTableView = (TableView) scene.lookup("#cartTableView");
        TableColumn<Item, String> itemNameCart = new TableColumn<>("Items");
        itemNameCart.setCellValueFactory(new PropertyValueFactory<>("itemName"));
        TableColumn<Item, Integer> itemAmountCart = new TableColumn<>("Amount");
        itemAmountCart.setCellValueFactory(new PropertyValueFactory<>("count"));
        TableColumn<Item, String> itemStatusCart = new TableColumn<>("Added");
        itemStatusCart.setCellValueFactory(new PropertyValueFactory<>("status"));
        cartTableView.setItems(model.getSelectedOrderList());
        cartTableView.getColumns().addAll(itemNameCart, itemAmountCart, itemStatusCart);
    }

//    private void reCalculatePaths() {
//        for (StoreCart pathCart :
//                model.getCarts()) {
//            if (!pathCart.isAvailable()) {
//                pathCart.restart();
//            }
//        }
//    }

    void getTime(double speed) {
        if (timeline != null) {
            timeline.getKeyFrames().clear();
        }
        timeline = new Timeline(
                new KeyFrame(Duration.millis(speed),
                        event -> {
                            event.consume();
                            minutes++;
                            if (minutes > 59) {
                                hours++;
                                minutes = 0;
                            }
                            if (hours > 23) {
                                hours = 0;
                            }

                            String string = hours + " : " + minutes;
                            timer.setText(string);
                        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        if(!pausePlay) {
            timeline.play();
        }
    }

    void faster() {
        if (slowerButton.isDisable()) {
            slowerButton.setDisable(false);
        }
        speed = speed / 2;
        getTime(speed);

        fasterButton.setDisable(speed == 250);

    }

    void slower() {
        if (fasterButton.isDisable()) {
            fasterButton.setDisable(false);
        }
        speed = speed * 2;
        getTime(speed);
        slowerButton.setDisable(speed == 2000);
    }


    /**
     * deleting given Item from orderingList
     * @param item
     */
    private void delItem(Item item) {
        for (Item it : model.getOrderingList()) {
            if (item == it) {
                for (Item allItem : model.getItemsList()) {
                    if (allItem.getItemName().equals(item.getItemName())) {
                        allItem.setCount(allItem.getCount() + item.getCount());
                        break;
                    }
                }
                model.getOrderingList().remove(it);
                orderTable.refresh();
                break;
            }
        }
    }

    /**
     * showing information to user on the left top corner
     * @param s given String to show
     */
    public void setInfo(String s) {

        if (!infoTimeline.getStatus().equals(Animation.Status.RUNNING)) {
            timeline.playFromStart();
        }
        infoLabel.setText(s);
        infoTimeline = new PauseTransition(Duration.seconds(10));
        infoTimeline.setOnFinished(e -> infoLabel.setText(null));
        infoLabel.setTextFill(Color.RED);
        PauseTransition color = new PauseTransition(Duration.seconds(1));
        color.setOnFinished(event -> infoLabel.setTextFill(Color.BLACK));
        color.play();
        infoTimeline.play();

    }

    /**
     * playing ot stopping the time and moving carts depends on pausePlayButton and barricadeButton
     */
    private void pausePlay() {
        pausePlay = !pausePlay;
        if (toggleBarricade) {
            pausePlay = true;
            setInfo("Making Barricade Mode On");
        }
        if (pausePlay) {
            for (StoreCart cart :
                    model.getCarts()) {
                cart.pause();
                timeline.pause();
            }
        } else {
            for (StoreCart cart :
                    model.getCarts()) {
                cart.play();
                timeline.play();
            }
        }
        if (pausePlay) {
            pp.setStyle("-fx-background-color: #CE2223; ");
            pausedLabel.setVisible(true);
        }else{
            pp.setStyle("-fx-background-color: GREEN; ");
            pausedLabel.setVisible(false);
        }
    }

    public boolean getPP() {
        return pausePlay;
    }

    /**
     * This functions add new object of Item to ObservableList orderingList
     * @param combo ComboBox with names of all items in warhouse
     * @param spinner Spinner with the count from 1 to count of selected Item
     */
    private void addToCart(ComboBox combo, Spinner spinner) {
        if (combo.getValue() != null) {
            String name = String.valueOf(combo.getValue());
            int w = model.getItemWeight(name);
            int Count = (int) spinner.getValue();
            Item item = new Item(name, Count, w);
            for (Item allItem : model.getItemsList()) {
                if (allItem.getItemName().equals(name)) {
                    allItem.setCount(allItem.getCount() - Count);
                    for (Item oItem : model.getOrderingList()) {
                        if (oItem.getItemName().equals(name)) {
                            model.getOrderingList().remove(oItem);
                            item.setCount(oItem.getCount() + Count);
                            break;
                        }
                    }
                    model.getOrderingList().add(item);
                    break;
                }
            }
            combo.setValue(null);
            spinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 0));
            allItemsTable.refresh();
        } else {
            setInfo("No item Selected");
        }
    }

    /**
     * This function imports all orders given in file and proceed to startOrder
     * @param selectedFile File with orders
     * @throws IOException validate given file
     */
    public void setOrderingListFromFile(File selectedFile) throws IOException {
        int orderCreated = 0;
        BufferedReader br = new BufferedReader(new FileReader(selectedFile));
        String line = br.readLine();
        while (line != null) {
            String[] itemVars = line.split(" ");
            if (itemVars.length == 2) {
                if (isNumeric(itemVars[1])) {
                    String name = itemVars[0].replaceAll("_", " ");
                    int w = model.getItemWeight(name);
                    if (w != 0) {
                        int c = Integer.parseInt(itemVars[1]);
                        model.getOrderingList().add(new Item(name, c, w));
                    } else {
                        setInfo(name + " not found in Warehouse items");
                    }
                }
            } else if (itemVars.length == 1) {
                processOrder_vol2();
                orderCreated++;
            }
            line = br.readLine();
        }
        if (orderCreated == 0) {
            cartTableView.refresh();
        } else {
            processOrder_vol2();
        }
    }

    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            Integer.parseInt(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    public void show(Stage s) {
        Scene scene = new Scene(borderpane, 1000, 800);
        s.setScene(scene);
//        s.setFullScreen(true);
        this.setUp(scene);

        s.show();
    }


    public Stage getStage() {
        return this.stage;
    }

    public ArrayList<ArrayList<Rotation>> getMyPath() {
        return model.getMyPath();
    }

    public boolean calculatePath(ObservableList<Item> orderList, StoreCart cart) {
        return model.calculatePath(orderList, cart);
    }

    public void CartTableRefresh() {
        if (selectedCart != null) {
            pbBar.setProgress(selectedCart.getAdded() / selectedCart.getOrderList().size());
        }
        cartTableView.refresh();
    }

    public GridPane getGridPane() {
        return grid;
    }

    /**
     * This function remove the pathRectangles from the main GridPane
     * @param row
     * @param column
     * @param removeRect
     */
    public void removeNodeByRowColumnIndex(final int row, final int column, Rectangle removeRect) {

        ObservableList<Node> children = grid.getChildren();
        for (Node node : children) {
            if (node instanceof Rectangle && GridPane.getRowIndex(node) == row && GridPane.getColumnIndex(node) == column) {
                if (node == removeRect) {
                    grid.getChildren().remove(node);
                    break;
                }
            }
        }
    }
}
