package gui;

import enums.Rotation;
import javafx.animation.*;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Point2D;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.Font;
import javafx.util.Duration;
import store.Item;
import store.StoreCart;
import java.util.ArrayList;

public class GCart {

    private final StoreCart cart;
    private final int carNumber;
    private final GWarehouse gWarehouse;
    private final Rectangle rect;
    private boolean selected;
    private final StackPane carPane;
    private ArrayList<ArrayList<Rotation>> myPath;
    private final SequentialTransition trajectory;
    private final ArrayList<Integer> linePathX;
    private final ArrayList<Integer> linePathY;
    private final ArrayList<Rectangle> pathRectangles;
    private final int row;
    private final int column;
    private Point2D startPos;
    private final StackPane stack;
    private double moveX;
    private double moveY;

    /**
     * This class implements GUI representation of StoreCart
     * @param cart connecting this with specific StoreCart
     * @param g GridPane of Main layout in Application
     * @param r row of a GridPane
     * @param c column of a GridPane
     * @param carNum number of this GCart
     * @param gWarehouse main GUI
     */
public GCart(StoreCart cart, GridPane g, int r, int c, int carNum, GWarehouse gWarehouse){

    startPos = new Point2D(0,0);

    pathRectangles = new ArrayList<>();
    row = r ;
    column = c;
    linePathX = new ArrayList<>();
    linePathY = new ArrayList<>();
    trajectory = new SequentialTransition();
    myPath = new ArrayList<>();
    selected = false;
    carPane = new StackPane();
    stack = new StackPane();
    this.cart = cart;
    carNumber = carNum;
    this.gWarehouse = gWarehouse;
    rect = new Rectangle(20, 12);
    rect.setFill(Color.RED);
    Label label = new Label();
    label.setTextFill(Color.BLUE);
    label.setFont(new Font("Arial",13));
    label.setText(Integer.toString(carNum));
    label.setStyle("-fx-font-weight: bold");
    Rectangle parking = new Rectangle(25,25);
    parking.setFill(Color.TRANSPARENT);
    parking.setStrokeWidth(3);
    parking.setStroke(Color.WHITE);
    Label p = new Label("P");
    p.setTextFill(Color.WHITE);
    p.setFont(new Font("Arial",20));

    EventHandler<MouseEvent> clickedHandler = ev -> {
        gWarehouse.setSelectedCart(this);
        ev.consume();
        };

    label.setOnMouseClicked(clickedHandler);
    rect.setOnMouseClicked(clickedHandler);
    carPane.getChildren().addAll(rect, label);
    carPane.setViewOrder(-2);
    stack.getChildren().addAll(parking,p);
    g.add(stack,c,r);
    g.add(carPane,c,r);
    cart.getMyGCart(this);

    }

    public void pause(){
    trajectory.pause();
    }
    public void play(){
    trajectory.play();
    }

    public void selected(boolean b) {
        selected = b;
        if (selected) {
            rect.setFill(Color.CHARTREUSE);
            if(cart.getOrderList().size() != 0) {
                drawCartPath();
            }
        }
        else {
            rect.setFill(Color.RED);
            if(pathRectangles.size()>0) {
                for (int removeIndex = 0; removeIndex < linePathX.size() - 1; removeIndex++) {
                    gWarehouse.removeNodeByRowColumnIndex(linePathY.get(removeIndex), linePathX.get(removeIndex), pathRectangles.get(removeIndex));
                }
                pathRectangles.clear();
            }
        }
    }

//    private void reCalculatePath(){
//        startPos = stack.localToParent(0,0);
//    Point2D actualPos = carPane.localToParent(0,0);
//    moveX = (actualPos.getX() - startPos.getX());
//    moveX = Math.floor(moveX/30);
//    moveY = (actualPos.getY() - startPos.getY());
//        moveY = Math.floor(moveY/30);
//    double actualColumn = column + moveX;
//    double actualRow = row + moveY;
//        cart.setPosX((int)actualColumn);
//        cart.setPosY((int)actualRow);
//    }

    private void drawCartPath() {
    gWarehouse.setInfo("Drawing path");
        for (int lineIndex = 0; lineIndex < linePathX.size() - 1; lineIndex++) {
        Rectangle pathRect = new Rectangle(10,10);
        pathRect.setFill(Color.INDIANRED);
            pathRectangles.add(pathRect);
            gWarehouse.getGridPane().add(pathRect, linePathX.get(lineIndex) , linePathY.get(lineIndex));
            GridPane.setHalignment(pathRect, HPos.CENTER);
        }
    }

    public ObservableList<Item> getOrderList() {
        return cart.getOrderList();
    }

    public String getNumber() {
        return Integer.toString(this.carNumber);
    }

    /**
     * getting path of given order
     */
    public void startOrder() {
        if (gWarehouse.calculatePath(cart.getOrderList(), cart)) {
            myPath = gWarehouse.getMyPath();
            this.startAnimation();
        } else {
            gWarehouse.setInfo("Could not find way to any Item");
        }
    }

    /**
     * starting the animation
     */
    private void startAnimation() {
        double currentX = rect.getX()+15;
        double currentY = rect.getY()+15;
        int xPath = column;
        int yPath = row;
        linePathX.add(column);
        linePathY.add(row);
        int moveAmount = 30;
        ArrayList<Transition> pathArray = new ArrayList<>();
        int duration = 0;
        if(moveX != 0 || moveY != 0){
            PathTransition p = new PathTransition();
            Path pathP = new Path(new MoveTo(currentX,currentY), new LineTo(moveX*30, moveY*30));
            p.setDuration(Duration.millis(1000));
            p.setPath(pathP);
            p.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
            p.setNode(carPane);
            pathArray.add(p);
            currentX = moveX*30;
            currentY = moveY*30;
        }
        for (int y = 0; y < myPath.size(); y++) {
            Path path = new Path();
            path.getElements().add(new MoveTo(currentX,currentY));
            if(moveX != 0 || moveY != 0){
                path.getElements().remove(0);
                path.getElements().add(new MoveTo(0,0));
                moveX = 0;
                moveY = 0;
            }
            for (int indexOrder = 0; indexOrder < myPath.get(y).size() ; indexOrder++) {
                if (Rotation.UP.equals(myPath.get(y).get(indexOrder))) {
                    currentY =  currentY - moveAmount;
                    yPath--;
                } else if (Rotation.DOWN.equals(myPath.get(y).get(indexOrder))) {
                    currentY = currentY + moveAmount;
                    yPath++;
                } else if (Rotation.RIGHT.equals(myPath.get(y).get(indexOrder))) {
                    currentX = currentX + moveAmount;
                    xPath++;
                } else if (Rotation.LEFT.equals(myPath.get(y).get(indexOrder))) {
                    currentX = currentX - moveAmount;
                    xPath--;
                }
                path.getElements().add(new LineTo(currentX, currentY));
                linePathX.add(xPath);
                linePathY.add(yPath);
                duration = duration + 1;
            }
            duration = duration * 500;
            duration = duration + myPath.get(y).size();
            PathTransition pathTransition = new PathTransition();
            int finalY = y;
            pathTransition.setOnFinished(event -> {
                if(cart.getOrderList().size()> finalY) {
                    cart.getOrderList().get(finalY).setStatus("Added");
                    gWarehouse.CartTableRefresh();
                }
                if(cart.getOrderList().size()> finalY + 1){
                    cart.getOrderList().get(finalY + 1).setStatus("Picking");
                }
            });
            pathTransition.setDuration(Duration.millis(duration));
            pathTransition.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
            pathTransition.setPath(path);
            pathTransition.setNode(carPane);
            PauseTransition pause = new PauseTransition(Duration.millis(1000));
            pathArray.add(pathTransition);
            pathArray.add(pause);
            duration = 0;
        }
        for (Transition t : pathArray) {
            trajectory.getChildren().add(t);
        }
        cart.getOrderList().get(0).setStatus("Picking");
        gWarehouse.CartTableRefresh();

        trajectory.setOnFinished(event -> {
            myPath.clear();
            cart.emptyOrderList();
            trajectory.getChildren().clear();
            gWarehouse.CartTableRefresh();
            if(cart.getWaiting().size()>0){
                cart.splitOrder();
                startOrder();
            }
            if(this.selected){
                gWarehouse.setSelectedCart(null);
            }
            if(!cart.isAvailable()){
                startOrder();
            }
            cart.resetPos();
        });

        if(!gWarehouse.getPP()){
            trajectory.play();
        }
    }

    public void slowRate(){
    trajectory.setRate(trajectory.getRate()/2);
    }

    public double getAdded() {
    double returnCount = 0;
        for (Item item :
                cart.getOrderList()) {
            if(item.getStatus().equals("Added")) {
                returnCount++;
            }
        }
        return returnCount;
    }

    public void fastRate() {
    trajectory.setRate(trajectory.getRate()*2);
    }

//    public void restartOrder() {
//        trajectory.stop();
//        trajectory.getChildren().clear();
//        myPath.clear();
//        reCalculatePath();
//        startOrder();
//    }
}
