package enums;

public enum Rotation {
    UP,
    DOWN,
    LEFT,
    RIGHT
}