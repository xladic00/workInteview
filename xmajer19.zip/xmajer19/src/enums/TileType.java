package enums;

/**
 * Enum for determining the type of tile
 */
public enum TileType {
    EMPTY,
    SHELF,
    LOADING_ZONE,
    CART,
    BARRICADE
}
