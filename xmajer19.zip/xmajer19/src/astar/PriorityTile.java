package astar;

import store.Tile;

/**
 * Class used as an entry for priority queue for AStar
 */
public class PriorityTile {
    private int priority;
    private Tile tile;

    public PriorityTile(int priority, Tile tile) {
        this.priority = priority;
        this.tile = tile;
    }

    public int getPriority() {
        return priority;
    }

    public Tile getTile() {
        return tile;
    }

    public void setTile(Tile tile) {
        this.tile = tile;
    }

    @Override
    public String toString() {
        return priority + " " + tile.getPosY() + " " + tile.getPosX();
    }
}
