package astar;

import java.util.Comparator;

/**
 * Class that implements Comparator interface used to compare Priority tiles in queue
 */
public class TileComparator implements Comparator<PriorityTile> {
    @Override
    public int compare(PriorityTile p1, PriorityTile p2) {
        if (p1.getPriority() < p2.getPriority()) {
            return -1;
        }
        else if (p1.getPriority() > p2.getPriority()) {
            return 1;
        }
        return 0;
    }
}
