package astar;

import enums.TileType;
import store.Tile;
import store.Warehouse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.PriorityQueue;

/**
 * This class implements the A* path-finding algorithm
 */
public class AStar {
    Warehouse warehouse;

    public AStar(Warehouse warehouse) {
        this.warehouse = warehouse;
    }

    /**
     * Method for finding the optimal path between 2 warehouse tiles
     * @param yFrom X coordinate of the starting tile
     * @param xFrom Y coordinate of the starting tile
     * @param xTo X coordinate of the destination tile
     * @param yTo Y coordinate of the destination tile
     * @return ArrayList containing tiles on the most optimal path
     */
    public ArrayList<Tile> solve(int yFrom, int xFrom, int xTo, int yTo) {
        //System.out.println(this);

//        System.out.println("current cart position: " + xFrom + "," + yFrom);
//        System.out.println("destination position: " + yTo + "," + xTo);
        PriorityQueue<PriorityTile> q = new PriorityQueue<>(new TileComparator());
        Tile start = warehouse.get(xFrom, yFrom);
        HashMap<Tile, Integer> minCosts = new HashMap<>();
        HashMap<Tile, Tile> cameFrom = new HashMap<>();

        int h = heuristic(start.getPosX(), start.getPosY(), xTo, yTo);

        q.add(new PriorityTile(h, start));
        minCosts.put(start, 0);

        // up, right, down, left
        int[][] dirs = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};

        while (!q.isEmpty()) {
//            System.out.println(q);
            PriorityTile cur = q.poll();
            int x = cur.getTile().getPosX();
            int y = cur.getTile().getPosY();

            if (x == xTo && y == yTo) {
                return reconstructPath(cameFrom, xTo, yTo);
            }

            for (int[] dir : dirs) {
                int newX = x + dir[0];
                int newY = y + dir[1];
                if (validCoords(newX, newY) || (newX == xTo && newY == yTo)) {
                    Tile tile = warehouse.get(newY, newX);
                    int cost = minCosts.get(cur.getTile()) + 1;
                    if (!(minCosts.containsKey(tile) && minCosts.get(tile) <= cost)) {
                        int f = heuristic(newX, newY, xTo, yTo) + cost;
                        minCosts.put(tile, cost);
                        cameFrom.put(tile, cur.getTile());
                        q.add(new PriorityTile(f, tile));
                    }
                }
            }
        }
        // todo
        // throw new RuntimeException("couldn't find path to shelf");
        return null;
    }

    private boolean validCoords(int x, int y) {
        if (x < 0 || x >= warehouse.getWidth() || y < 0 || y >= warehouse.getHeight()) {
            return false;
        }
        return warehouse.get(y, x).getType() == TileType.EMPTY;
    }

    private ArrayList<Tile> reconstructPath(HashMap<Tile, Tile> cameFrom, int xGoal, int yGoal) {
        ArrayList<Tile> path = new ArrayList<>();
        Tile tile = warehouse.get(yGoal, xGoal);

        while (cameFrom.containsKey(tile)) {
            path.add(tile);
            tile = cameFrom.get(tile);
        }
        path.add(tile);

        Collections.reverse(path);
        return path;
    }
    // Manhattan distance
    private int heuristic(int x, int y, int xGoal, int yGoal) {
        return Math.abs(x - xGoal) + Math.abs(y - yGoal);
    }


}
