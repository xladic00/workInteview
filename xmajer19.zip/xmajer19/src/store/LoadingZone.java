package store;

import enums.TileType;

/**
 * Class for a tile on the grid representing loading and unloading zone for carts - extends Tile class
 */
public class LoadingZone extends Tile {

    /**
     * @param posX X coordinate of the shelf on the warehouse grid
     * @param posY Y coordinate of the shelf on the warehouse grid
     */
    public LoadingZone(int posX, int posY) {
        super(posX, posY, TileType.LOADING_ZONE);
    }

    @Override
    public String toString() {
        return "!";
    }
}
