package store;

import astar.AStar;
import enums.Rotation;
import enums.TileType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import utils.Utils;
import java.io.*;
import java.util.*;


/**
 * This class represents a whole warehouse, combining and managing functionalities of all other classes
 */
public class Warehouse {
    private final ArrayList<ArrayList<Tile>> map;
    private final ArrayList<StoreShelf> shelves;

    private LoadingZone loadingZone;
    private final int width;
    private final int height;
    private final ArrayList<StoreCart> carts;
    private final AStar aStar;

    private final ObservableList<Item> itemsList;
    private ObservableList<Item> orderingList;
    private ObservableList<Item> selectedOrderList;
    private ArrayList<ArrayList<Item>> orderQueue;

    private List<Tile> path;
    private ArrayList<ArrayList<Rotation>> pathMoves;
    private ArrayList<Item> skippedItems;
    private int barricadeCount;
    private int barricadeLastCount;

    /**
     * Method to initialize a warehouse map grid based on predefined rules with all possible tile types (EmptyTile(-),
     * LoadingZone(!), StoreShelf(#)), distribute initial contents to shelves and initialize store carts.
     * @param gridFileName name of the file used for loading a warehouse map
     * @param contentFileName name of the file used for loading a warehouse's initial content
     * @throws IOException
     */
    public Warehouse(String gridFileName, String contentFileName) throws IOException {
        File grid = new File(gridFileName);
        carts = new ArrayList<>();
        aStar = new AStar(this);
        path = new ArrayList<>();
        orderingList = FXCollections.observableArrayList();
        selectedOrderList = FXCollections.observableArrayList();
        orderQueue = new ArrayList<>();
        pathMoves = new ArrayList<>();
        skippedItems = new ArrayList<>();
        barricadeCount = 0;
        barricadeLastCount = 0;

        BufferedReader br = new BufferedReader(new FileReader(grid));
        String line = br.readLine();
        map = new ArrayList<>();
        shelves = new ArrayList<>();
        int i = 0;
        while (line != null) {
            int j = 0;
            ArrayList<Tile> lineArr = new ArrayList<>();
            for (char c : line.toCharArray()) {
                switch (c) {
                    case 'x': {
                        continue;
                    }
                    case '-': {
                        lineArr.add(new EmptyTile(j, i));
                        break;
                    }
                    case '#': {
                        StoreShelf shelf = new StoreShelf(j, i);
                        lineArr.add(shelf);
                        shelves.add(shelf);
                        break;
                    }
                    case '!': {
                        loadingZone = new LoadingZone(j, i);
                        lineArr.add(loadingZone);
                        break;
                    }
                    case 'C': {
                        StoreCart cart = new StoreCart( this,25001, j, i);
                        lineArr.add(cart);
                        carts.add(cart);
                        break;
                    }
                }
                j++;
            }
            map.add(lineArr);
            line = br.readLine();
            i++;
        }


        if (map.isEmpty() || map.get(0).isEmpty()) {
            throw new RuntimeException("invalid input");
        }

        width = map.get(0).size();
        height = map.size();
        File content = new File(contentFileName);

        br = new BufferedReader(new FileReader(content));
        line = br.readLine();
        ArrayList<String> lines = new ArrayList<>();
        while (line != null) {
            lines.add(line);
            line = br.readLine();
        }

        itemsList = Utils.parseStoreItems_vol2(lines);
        for (Item item : itemsList) {
            boolean placed = false;
            if (item.getAllWeight() > shelves.get(0).getCapacity()) {
            problemItemFunction(item);
                continue;
            }
            for (StoreShelf shelf : shelves) {
                if (shelf.isEmpty()) {
                    shelf.giveItem(item);
                    placed = true;
                    break;
                } else if ((shelf.available_vol2(item.getAllWeight())) && (shelf.getGoodsNames().size()<2)) {
                    shelf.giveItem(item);
                    placed = true;
                    break;
                }
            }
            if (!placed) {
                throw new RuntimeException("more goods than shelves, shouldn't occur");
            }
        }
    }

    public void sortOrderingList() {
        if(orderingList.size()>1) {
            int xLoadingZone = loadingZone.getPosX();
            int yLoadingZone = loadingZone.getPosY();
            ArrayList<Integer> itemsDists = new ArrayList<>();
            skippedItems = new ArrayList<>();

            for (Item item : orderingList) {
                for (StoreShelf shelf : shelves) {
                    if (shelf.getGoodsNames().contains(item.getItemName())) {
                        path = aStar.solve(xLoadingZone, yLoadingZone, shelf.getPosX(), shelf.getPosY());
                        if (path != null) {
                            Integer itemDist = path.size();
                            itemsDists.add(itemDist);
                        } else {
                            skippedItems.add(item);
                            System.out.println(item + " behind barricade, cannot pick it up");
                        }
                        break;
                    }
                }
            }

            for (Item backItem : skippedItems) {
                setItemCount(backItem.getItemName(),(getItemCount(backItem.getItemName()) + backItem.getCount()));
            }
            orderingList.removeAll(skippedItems);
            ArrayList<Integer> itemsDistsSorted = new ArrayList<>(itemsDists);
            Collections.sort(itemsDistsSorted);
            int[] indices = new int[itemsDists.size()];
            for (int i = 0; i < itemsDists.size(); i++) {
                indices[i] = itemsDists.indexOf(itemsDistsSorted.get(i));
            }
            ArrayList<Item> temp = new ArrayList(orderingList);
            for (int i = 0; i < orderingList.size(); i++) {
                orderingList.set(indices[i], temp.get(i));
            }
        }
    }
    private void setItemCount(String itemName, int i) {
        for (Item itemAll :
                itemsList) {
            if (itemAll.getItemName().equals(itemName)) {
                itemAll.setCount(i);
            }
        }
    }

    public void setBarricade(int posY, int posX) {
        if (map.get(posY).get(posX).getType() == TileType.EMPTY) {
            map.get(posY).set(posX, new Barricade(posX, posY));
            barricadeCount = barricadeCount + 1;
            System.out.println(barricadeCount);
        } else {
            map.get(posY).set(posX, new EmptyTile(posX, posY));
            barricadeCount = barricadeCount - 1;
        }
    }

    private void problemItemFunction(Item item) {
        boolean stored = false;
        item.setCount(item.getCount()/2);
        if(item.getAllWeight()< shelves.get(0).getCapacity()) {
            for (int i = 0; i < 2; i++) {
                for (StoreShelf shelf :
                        shelves) {
                    if (shelf.isEmpty()) {
                        shelf.giveItem(item);
                        stored = true;
                        break;
                    }
                }
                if (!stored) {
                    for (StoreShelf avShelf :
                            shelves) {
                        if (avShelf.available_vol2(item.getAllWeight())) {
                            avShelf.giveItem(item);
                            stored = true;
                            break;
                        }
                    }
                }
            }
            if(!stored){
                problemItemFunction(item);
            }
        }else{
            problemItemFunction(item);
        }
    }
    public void addToQueue() {
        ArrayList<Item> orderingListTemp = new ArrayList<>();
        for (Item item : orderingList) {
            orderingListTemp.add(item);
        }
        orderQueue.add(orderingListTemp);
        orderingList.clear();
    }

    public Tile get(int x, int y) {
        return map.get(x).get(y);
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public ObservableList<Item> getItemsList() { return itemsList; }
    public ArrayList<String> getItemsNames(){
        ArrayList<String> l = new ArrayList<>();
        for (Item item:itemsList) {
            l.add(item.getItemName());
        }
        return l;
    }

    public ArrayList<StoreShelf> getShelves() {
        return shelves;
    }

    public  ArrayList<StoreCart> getCarts() {
        return carts;
    }

    public ObservableList<Item> getOrderingList()
    {
        return orderingList;
    }

    public ObservableList getSelectedOrderList() {
        return selectedOrderList; }

    public int getItemWeight(String name) {
        int w = 0;
        for (Item item:itemsList) {
            if(item.getItemName().equals(name)){
                w =  item.getItemWeight();
                break;
            }
        }
        return w;
    }

    public void setSetSelectedOrderList(ObservableList<Item> l) {
        selectedOrderList.clear();
        selectedOrderList.addAll(l);
    }
    public Integer getBarricadeCount(){
        return barricadeCount;
    }
    public boolean calculatePath(ObservableList<Item> orderingList, StoreCart cart) {
         ArrayList<List<Tile>> path_vol2 = new ArrayList<>();
        List<Tile> last_path = null;
        int xCart = cart.getPosX();
        int yCart = cart.getPosY();

        for (Item item : orderingList) {
            if(item.getStatus().equals("Added")){
                continue;
            }
            boolean inStock = false;
            for (StoreShelf shelf : shelves) {
                if (shelf.getGoodsNames().contains(item.getItemName())) {
                    inStock = true;
                    path = aStar.solve(xCart, yCart, shelf.getPosX(), shelf.getPosY());
                        if(path.size()==2){
                            xCart = last_path.get(last_path.size() - 2).getPosX();
                            yCart = last_path.get(last_path.size() - 2).getPosY();
                            path = aStar.solve(xCart, yCart, shelf.getPosX(), shelf.getPosY());
                            path.add(0,last_path.get(last_path.size()-1));
                        }
                        path_vol2.add(path);
                        xCart = path.get(path.size() - 1).getPosX();
                        yCart = path.get(path.size() - 1).getPosY();
                        last_path = path;
                    break;
                }
            }
            if (!inStock) {
                System.out.println();
                System.out.println(item.getItemName() + " not in stock, proceeding to load the next item");
                System.out.println();
            }
        }


        if(path_vol2.size() != 0) {
            path = aStar.solve(xCart, yCart, loadingZone.getPosX(), loadingZone.getPosY());
            path_vol2.add(path);
            cart.resetPos();
            path = aStar.solve(loadingZone.getPosX(), loadingZone.getPosY(), cart.getPosX(), cart.getPosY());
            path_vol2.add(path);
        }else{
            return false;
        }

        for (int y = 0; y < path_vol2.size(); y++) {
            ArrayList<Rotation> pathRotations = new ArrayList<>();
            for (int i = 0; i < path_vol2.get(y).size() - 1; i++) {
                int xPosCurr = path_vol2.get(y).get(i).getPosX();
                int yPosCurr = path_vol2.get(y).get(i).getPosY();
                int xPosNext = path_vol2.get(y).get(i + 1).getPosX();
                int yPosNext = path_vol2.get(y).get(i + 1).getPosY();
                int[] rot = {xPosNext - xPosCurr, yPosNext - yPosCurr};

                if (Arrays.equals(rot, new int[]{0, -1})) {
                    pathRotations.add(Rotation.UP);
                } else if (Arrays.equals(rot, new int[]{0, 1})) {
                    pathRotations.add(Rotation.DOWN);
                } else if (Arrays.equals(rot, new int[]{1, 0})) {
                    pathRotations.add(Rotation.RIGHT);
                } else if (Arrays.equals(rot, new int[]{-1, 0})) {
                    pathRotations.add(Rotation.LEFT);
                }
            }
            pathMoves.add(pathRotations);
        }
        return true;
    }
    public ArrayList<Item> getSkippedItems(){
        return skippedItems;
    }

    public ArrayList<ArrayList<Rotation>> getMyPath() {
        ArrayList<ArrayList<Rotation>>localArray = new ArrayList<>(pathMoves);
        pathMoves.clear();
        return new ArrayList<>(localArray);
    }

    public Integer getItemCount(String name) {
        for (Item item :
                itemsList) {
            if (item.getItemName().equals(name)){
                return item.getCount();
            }
        }
        return null;
    }

    public ArrayList<ArrayList<Item>> getQueue() {
        return orderQueue;
    }

    public void resetBarricadeCount() {
        barricadeCount = barricadeLastCount;
    }

    public Integer getBarricadeCountLast() {
        return barricadeLastCount;
    }
}
