package store;

/**
 * Class for storing variable of any Item
 */
public class Item {

    private final String itemName;
    private int count;
    private final int itemWeight;
    private String status;


    /**
     * @param itemName name of item
     * @param count count of items
     * @param itemWeight weight of single item
     */
    public Item(String itemName, int count, int itemWeight){

        this.itemName = itemName;
        this.itemWeight = itemWeight;
        this.count = count;
        this.status = "NOPE";
    }

    public int getItemWeight() {
        return itemWeight;
    }
    public int getCount() {
        return count;
    }
    public String getItemName() {
        return itemName;
    }

    public int getAllWeight() { return count*itemWeight; }

    public String getStatus() {
        return status;
    }

    public boolean removeCount(int numItems) {
        if(this.count>numItems){
            this.count -= numItems;
            return true;
        }
        return false;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setCount(int i) {
        count = i;
    }
}
