package store;

import enums.TileType;

import java.util.Objects;

/**
 * This class represents a general tile on the warehouse grid
 */
public abstract class Tile {
    private int posX;
    private int posY;
    private TileType type;

    /**
     * @param posX X coordinate of the shelf on the warehouse grid
     * @param posY Y coordinate of the shelf on the warehouse grid
     * @param type type of the tile (EmptyTile, LoadingZone, StoreShelf)
     */
    public Tile(int posX, int posY, TileType type) {
        this.posX = posX;
        this.posY = posY;
        this.type = type;
    }

    public TileType getType() {
        return type;
    }

    public int getPosX() {
        return posX;
    }

    public void setPosX(int posX) {
        this.posX = posX;
    }

    public int getPosY() {
        return posY;
    }

    public void setPosY(int posY) {
        this.posY = posY;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Tile tile = (Tile) o;
        return posX == tile.posX && posY == tile.posY && type == tile.type;
    }

    @Override
    public int hashCode() {
        return Objects.hash(posX, posY, type);
    }

    public void setType(TileType type) {
        this.type = type;
    }
}
