package store;

import enums.TileType;
import gui.GShelf;

import java.util.ArrayList;

/**
 * This class represents a single shelf in warehouse - extends Tile class
 */
public class StoreShelf extends Tile {
    private ArrayList<Item> goods;
    private final int capacity;
    private GShelf gShelf;
    /**
     * @param posX X coordinate of the shelf on the warehouse grid
     * @param posY Y coordinate of the shelf on the warehouse grid
     */
    public StoreShelf(int posX, int posY) {
        super(posX, posY, TileType.SHELF);
        goods = new ArrayList<Item>();
        this.capacity = 50000;
    }

    public ArrayList<String> getGoodsNames(){
        ArrayList<String> names = new ArrayList<String>();
        for (int i = 0; i < goods.size(); i++) {
            names.add(goods.get(i).getItemName());
        }
        return names;
    }

    public ArrayList<Item> getGoods() {
        return goods;
    }

    public boolean available_vol2(int  input) {
        int w = 0;
        if(goods != null){
            for (Item item: goods) {
                w =+ item.getItemWeight()*item.getCount();
            }
        }
        w = w + input;
        return w<capacity ;
    }

    @Override
    public String toString() {
        return "#";
    }

    public void giveItem(Item item) {
        goods.add(item);
    }
    public void getMyGShelf(GShelf gShelf){
        this.gShelf = gShelf;
    }

    public boolean remove_vol2(String itemName, int numItems) {
        try{
            return goods.get(this.getGoodsNames().indexOf(itemName)).removeCount(numItems);

        }catch(NullPointerException e){
            System.out.println(itemName + " is not in this Shelf");
            return false;
        }
    }

    public boolean isAvailable() {
        if((goods.size() == 0) || (this.getWeight()<this.capacity/2)){
            return true;
        }else{
            return false;
        }
    }

    private float getWeight() {
        float w = 0;
        for (Item item :
                goods) {
           w = w + item.getCount()*item.getItemWeight();
        }
        return w;
    }

    public boolean isEmpty() {
        return goods.size() == 0;
    }

    public int getCapacity() {
        return capacity;
    }
}