package store;
import enums.TileType;
/**
 * Class for an empty tile on the grid representing an aisle in the warehouse where the cart can move - extends Tile class
 */
public class Barricade extends Tile {
    /**
     * @param posX X coordinate of the shelf on the warehouse grid
     * @param posY Y coordinate of the shelf on the warehouse grid
     */
    public Barricade(int posX, int posY) {
        super(posX, posY, TileType.BARRICADE);
    }
    @Override
    public String toString() {
        return "%";
    }
}
