package store;

import enums.TileType;
import gui.GCart;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.ArrayList;

/**
 * This class defines a store cart in the warehouse
 */
public class StoreCart  extends Tile{
    private int capacity;
    private int capacityAvailable;
    private int posX;
    private int posY;
    private int originX;
    private int originY;
    private Warehouse model;
    private ObservableList<Item> orderList;
    private GCart gCart;
    private ArrayList<Item> itemsWaiting = new ArrayList<>();
    private int load;

    /**
     * StoreCart constructor
     * @param warehouse main owner
     * @param capacity Cart load capacity (number of items)
     * @param posX X coordinate of the cart on the warehouse grid
     * @param posY Y coordinate of the cart on the warehouse grid
     */
    public StoreCart(Warehouse warehouse, int capacity, int posX, int posY) {

        super(posX,posY,TileType.CART);
        this.capacity = capacity;
        this.capacityAvailable = capacity;
        this.posX = posX;
        this.posY = posY;
        this.originX = posX;
        this.originY = posY;
        orderList = FXCollections.observableArrayList();
        model = warehouse;
    }

    public int getCapacityAvailable() {
        return capacityAvailable;
    }

    public int getPosX() {
            return posX;
    }
    public int getPosY() {
            return posY;
    }

    public ObservableList<Item> getOrderList() {
        return orderList;
    }

    public void setPosX(int posX) {
        this.posX = posX;
        System.out.println();
    }

    public void setPosY(int posY) {
        this.posY = posY;
    }

    public int getCapacity() {
        return capacity;
    }

    public boolean isAvailable() {
            if (model.getQueue().size() > 0) {
               orderList.addAll(model.getQueue().get(0));
               model.getQueue().remove(0);
            }
            return orderList.size()==0;
    }


    public void getMyGCart(GCart gCart) {
        this.gCart = gCart;
    }

    public void startOrder() {
        gCart.startOrder();
    }

    public void emptyOrderList() {
      orderList.removeIf((Item item) -> item.getStatus().equals("Added"));
        orderList.removeIf((Item item) -> item.getStatus().equals("Skipped"));
    }

    public void pause() {
        gCart.pause();
    }

    public void play() {
        gCart.play();
    }

    public void fastRate() {
        gCart.fastRate();
    }

    public void slowRate() {
        gCart.slowRate();
    }

//    public void restart() {
//        gCart.restartOrder();
//    }
    public ArrayList<Item> getWaiting() {
        return itemsWaiting;
    }
    public void setOrderList(ObservableList<Item> l){
        orderList.removeAll(orderList);
        load = 0;
        for (int tem = 0; tem < l.size(); tem++) {
            orderList.add(l.get(tem));
            load += l.get(tem).getAllWeight();
        }
        itemsWaiting.addAll(orderList);
    }
    public void splitOrder() {
        ArrayList<Item> itemsWaitingTmp = new ArrayList<>();
        if (load >= capacity) {
            load = 0;
            orderList.clear();
            for (Item item : itemsWaiting) {
                if (item.getAllWeight() > capacity) {
                    Item itemTmpOrder = new Item(item.getItemName(), item.getCount(), item.getItemWeight());
                    itemTmpOrder.setCount((int) Math.floor((capacity - load) / item.getItemWeight()));
                    if (itemTmpOrder.getCount() > 0) {
                        orderList.add(itemTmpOrder);
                    }

                    Item itemTmpWaiting = new Item(item.getItemName(), item.getCount(), item.getItemWeight());
                    itemTmpWaiting.setCount(item.getCount() - itemTmpOrder.getCount());
                    itemsWaitingTmp.add(itemTmpWaiting);

                    load = capacity;
                } else if (item.getAllWeight() > (capacity - load)) {
                    itemsWaitingTmp.add(item);
                } else {
                    orderList.add(item);
                    load += item.getAllWeight();
                }
            }
            itemsWaiting.clear();
            itemsWaiting.addAll(itemsWaitingTmp);
        } else {
            orderList.clear();
            orderList.addAll(itemsWaiting);
            itemsWaiting.clear();
        }
    }

    public void resetPos() {
        setPosX(originX);
        setPosY(originY);
    }

    public int getOriginX() {
        return originX;
    }

    public int getOriginY() {
        return originY;
    }
}
