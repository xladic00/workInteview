import gui.GWarehouse;
import javafx.application.Application;
import javafx.stage.Stage;
import store.Warehouse;
import utils.Utils;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Main extends Application {

    private static Warehouse warehouse;


    public static void main(String[] args) throws IOException {

        try {
           warehouse = new Warehouse("data/grid.txt", "data/content.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        GWarehouse gwarehouse = new GWarehouse(warehouse, primaryStage );
        gwarehouse.show(primaryStage);
    }
}
