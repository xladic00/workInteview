$ wget https://gluonhq.com/products/javafx/openjfx-11.0.2_windows-x64_bin-sdk.zip -O ../lib
$ unzip openjfx-11.0.2_windows-x64_bin-sdk.zip